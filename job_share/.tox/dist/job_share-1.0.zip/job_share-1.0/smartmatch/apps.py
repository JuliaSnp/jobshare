from django.apps import AppConfig


class SmartmatchConfig(AppConfig):
    name = 'smartmatch'
